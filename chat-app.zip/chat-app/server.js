const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/userModel');
const Chat = require('./models/chatModel');
const http = require('http');


dotenv.config({ path: './config.env' });
const app = require('./app');

// Connect to MongoDB
const DB = process.env.DATABASE.replace('<PASSWORD>', process.env.DATABASE_PASSWORD);
mongoose.connect(DB, {
  useNewUrlParser: true,
  useCreateIndex: true,
  useFindAndModify: false,
  useUnifiedTopology: true
})
.then(() => console.log('DB Connection Successful'))
.catch(err => console.error('DB Connection Error:', err));

//HTTP server
const server = http.createServer(app);

// Set up Socket.IO
const io = require('socket.io')(server);
const usp = io.of('/user-namespace');

// Socket.IO logic
usp.on('connection', async function(socket) {
  console.log('User Connected');
  
  var userId = socket.handshake.auth.token;

  await User.findByIdAndUpdate({ _id: userId }, { $set:{ is_online:'1' } });

  // Broadcast online status
  socket.broadcast.emit('getOnlineUser', { user_id: userId });

  socket.on('disconnect', async function(){
    console.log('User Disconnected');

    var userId = socket.handshake.auth.token;
    await User.findByIdAndUpdate({ _id: userId }, { $set:{ is_online:'0' } });

    // Broadcast offline status
    socket.broadcast.emit('getOfflineUser', { user_id: userId });

  });

  // Chatting implementation
  socket.on('newChat', function(data){
    socket.broadcast.emit('loadNewChat', data);
  });

  // Load old chats
  socket.on('existsChat',async function(data){
    var chats = await Chat.find({ $or:[
      { sender_id: data.sender_id, receiver_id: data.receiver_id },
      { sender_id: data.receiver_id, receiver_id: data.sender_id },
    ]});

    socket.emit('loadChats', { chats: chats });
  });

  // Delete chats
  socket.on('chatDeleted', function(id){
    socket.broadcast.emit('chatMessageDeleted', id);
  });

  // Update chats
  socket.on('chatUpdated', function(data){
    socket.broadcast.emit('chatMessageUpdated', data);
  });

});

// Handle uncaught exceptions
process.on('uncaughtException', err => {
  console.log('UNCAUGHT EXCEPTION! Shutting Down....');
  console.log(err.name, err.message);
  process.exit(1);
});

// Handle unhandled rejections
process.on('unhandledRejection', err => {
  console.log('UNHANDLED REJECTION! Shutting Down....');
  console.log(err.name, err.message);
  server.close(() => {
    process.exit(1);
  });
});

// Start the server
const port = process.env.PORT || 3000;
server.listen(port, () => {
  console.log(`App running on port ${port}...`);
});
