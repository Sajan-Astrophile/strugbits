const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser'); 
const cookieParser = require('cookie-parser');

const AppError = require('./utils/appError');
const globalErrorHandler = require('./controllers/errorController');
const chatRoute = require('./routes/chatRoute')
const userRoute = require('./routes/userRoute');
const rateLimit = require("express-rate-limit");


// Create Express app
const app = express();

// Configure session middleware
app.use(session({
  secret: 'your-secret-key', // Set a secret key for session encryption
  resave: false,
  saveUninitialized: false
}));

// Use cookie parser middleware
app.use(cookieParser());

// Use body-parser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Set up static files
app.use(express.static('public'));


// EJS View Engine
app.set('view engine', 'ejs');
app.set('views', './views');

// Cross-Site Scripting (XSS) protection
app.use((req, res, next) => {
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

// API rate limiting to protect against abuse and potential denial-of-service attacks
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, 
  max: 100
});
app.use("/api/", apiLimiter); // Apply rate limiting to API routes

// ROUTES
app.use('/', userRoute);
app.use('/api', chatRoute);

app.all('*', (req, res, next) => {
  next(new AppError(`Can't find ${req.originalUrl} on this server`, 404));
});

app.use(globalErrorHandler);

module.exports = app;