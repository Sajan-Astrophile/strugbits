const express = require('express');
const router = express.Router();
const chatController = require('../controllers/chatController')
const userController = require('../controllers/userController');
const upload = userController.upload;
const auth = require('../middlewares/auth');

router.get('/register', auth.isLogout, userController.registerLoad);
router.post('/register', upload.single('image'), userController.register);


router.get('/', auth.isLogout,userController.loadLogin);
router.post('', userController.login);
router.get('/logout', auth.isLogin,userController.logout);

router.get('/dashboard', auth.isLogin, userController.loadDashboard);

router.post('/save-chat', chatController.saveChat);
router.post('/delete-chat', chatController.deleteChat);
router.post('/update-chat', chatController.updateChat);

module.exports = router;

