const express = require('express');
const chatController = require('../controllers/chatController')

const router = express.Router();

router.get('/chats/:userId', chatController.getChatList);
router.delete('/delete-chat-for-everyone/:id', chatController.deleteChatForEveryone);
router.get('/search', chatController.search);


module.exports = router;
