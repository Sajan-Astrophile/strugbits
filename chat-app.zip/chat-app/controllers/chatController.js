const AppError = require('../utils/appError');
const catchAsync = require('../utils/catchAsync');
const Chat = require('../models/chatModel');
const User = require('../models/userModel');


// Task 2: Real-time Chat APIs
exports.saveChat = catchAsync(async (req, res) => {
    const { sender_id, receiver_id, message } = req.body;

    const newChat = new Chat({
        sender_id,
        receiver_id,
        message,
    });

    await newChat.save();

    res.status(200).send({ success: true, msg: 'Chat inserted!', data: newChat });
});



// Task 5: 'Delete for Me' Feature
exports.deleteChat = catchAsync(async (req, res) => {
    const { id } = req.body;

    if (!id) {
        return new AppError('Please provide chat ID', 400);
    }

    await Chat.deleteOne({ _id: id });

    res.status(200).send({ success: true });
});


// Task 6: 'Delete for Everyone' Feature
exports.deleteChatForEveryone = catchAsync(async (req, res) => {
    const { id } = req.params; // Extract chat ID from URL parameters

    if (!id) {
        return new AppError('Please provide chat ID', 400);
    }

    const deletedChat = await Chat.findByIdAndDelete(id);

    if (!deletedChat) {
        return new AppError('Chat not found', 404);
    }

    res.status(200).send({ success: true });
});



exports.updateChat = catchAsync(async (req, res) => {
    const { id, message } = req.body;

    if (!id || !message) {
        return new AppError('Please provide chat ID and message', 400);
    }

    await Chat.findByIdAndUpdate({ _id: id }, { $set: { message } });

    res.status(200).send({ success: true });
});

// Task 3: Chat List API
exports.getChatList = catchAsync(async (req, res, next) => {
    const userId = req.params.userId;
  
    try {
      const chats = await Chat.find({
        $or: [
          { sender_id: userId }, 
          { receiver_id: userId }
        ]
      }).populate('sender_id receiver_id');
  
      if (!chats || chats.length === 0) {
        return next(new AppError('No chats found for this user', 404));
      }
  
      res.status(200).json({
        status: 'success',
        data: {
          chats
        }
      });
    } catch (err) {
      return next(new AppError('Error retrieving chat conversations', 500));
    }
  });

  // Task 4: Search Feature
  exports.search = catchAsync(async (req, res, next) => {
    const { query } = req.query;
  
    if (!query) {
      return next(new AppError('Please provide a search query', 400));
    }
  
    // Search for users
    const users = await User.find({ name: { $regex: query, $options: 'i' } });
  
    // Search for messages
    const messages = await Chat.find({ message: { $regex: query, $options: 'i' } })
      .populate('sender_id', 'name')
      .populate('receiver_id', 'name');
  
    res.status(200).json({
      status: 'success',
      data: {
        users,
        messages,
      },
    });
  });
  