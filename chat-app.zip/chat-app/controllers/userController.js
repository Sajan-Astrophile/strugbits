const multer = require('multer');
const path = require('path');
const User = require('../models/userModel');
const bcrypt = require('bcrypt');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');

// Multer configuration
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, '../public/images'));
    },
    filename: function (req, file, cb) {
        const name = Date.now() + '-' + file.originalname;
        cb(null, name);
    }
});

const upload = multer({ storage: storage });

module.exports.upload = upload;


exports.registerLoad = async (req, res) => {
    try {
        res.render('register');
    } catch (error) {
        console.log(error.message);
    }
}

// Task 1: Authentication APIs
exports.register = catchAsync(async (req, res) => {
    // Check if the email already exists in the database
    const existingUser = await User.findOne({ email: req.body.email });
    if (existingUser) {
        return next(new AppError('Email already exists. Please use a different email.', 400));
    }

    const passwordHash = await bcrypt.hash(req.body.password, 10);

    const user = new User({
        name: req.body.name,
        email: req.body.email,
        // image: 'images/' + req.file.filename,
        password: passwordHash
    });

    // If file is uploaded, set image property
    if (req.file) {
        user.image = 'images/' + req.file.filename;
    }

    await user.save();

    res.render('register', { message: 'Your Registration has been Completed!' });

});


exports.loadLogin = async (req, res) => {
    try {
        res.render('login');
    } catch (error) {
        console.log(error.message);
    }
}


exports.login = catchAsync(async (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    const userData = await User.findOne({ email: email });
    if (!userData) {
        return res.render('login', { message: 'Email and Password is Incorrect!' });
    }

    const passwordMatch = await bcrypt.compare(password, userData.password);
    if (!passwordMatch) {
        return res.render('login', { message: 'Email and Password is Incorrect!' });
    }

    req.session.user = userData;
    res.cookie(`user`, JSON.stringify(userData));
    res.redirect('/dashboard');
});


exports.logout = async (req, res) => {
    try {
        res.clearCookie('user');
        req.session.destroy();
        res.redirect('/');
    } catch (error) {
        console.log(error.message);
    }
}

exports.loadDashboard = catchAsync(async (req, res) => {
    try {
        var users = await User.find({ _id: { $nin: [req.session.user._id] } });
        res.render('dashboard', { user: req.session.user, users: users });
    } catch (error) {
        console.log(error.message);
    }
});

